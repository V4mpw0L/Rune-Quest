# Contributing

When contributing to this repository, please first discuss the change you wish to make via an issue with the owner(s) of this repository before making a change. 

Please note we have a code of conduct, please follow it in all your interactions with the project.
