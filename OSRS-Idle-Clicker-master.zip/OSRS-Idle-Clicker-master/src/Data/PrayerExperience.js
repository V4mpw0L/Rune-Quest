export default {
  "Bones": 4.5,
	"Big bones": 15,
	"Baby dragon bones": 30,
	"Dragon bones": 72,
	"Wyvern bones": 72,
	"Lava dragon bones": 85,
	"Superior dragon bones": 150
}